# Grafana Dashboard Setup for cloud.gov

## Overview
This guide provides instructions for setting up the ZAP Security Scanning Dashboard in cloud.gov's Grafana instance.

## Prerequisites
- Access to cloud.gov's Grafana instance
- Prometheus data source configured
- Appropriate permissions to create dashboards

## Setup Instructions

### 1. Access cloud.gov Grafana
```bash
# Navigate to your cloud.gov Grafana instance
# Typically: https://grafana.fr.cloud.gov
```

### 2. Configure Prometheus Data Source
If not already configured:
1. Go to Configuration → Data Sources
2. Click "Add data source"
3. Select "Prometheus"
4. Configure:
   - Name: `Prometheus`
   - URL: Your Prometheus endpoint (e.g., `https://prometheus.fr.cloud.gov`)
   - Access: Server (default)
   - Auth: As required by your setup

### 3. Import Dashboard

#### Option A: Import via JSON
1. Navigate to Dashboards → Import
2. Copy the contents of `ci/grafana/dashboard.json`
3. Paste into the "Import via panel json" field
4. Click "Load"
5. Select your Prometheus data source
6. Click "Import"

#### Option B: Import via File Upload
1. Navigate to Dashboards → Import
2. Click "Upload JSON file"
3. Select `ci/grafana/dashboard.json`
4. Select your Prometheus data source
5. Click "Import"

### 4. Configure Metrics Export Pipeline

Add the metrics export task to your Concourse pipeline:

```yaml
# Add to ci/child-pipelines/zap-dast.yml after push-defectdojo task
- task: export-metrics
  file: zap-runner/ci/tasks/export-metrics.yml
  input_mapping:
    zap-reports: zap-reports-((context))
  params:
    SCAN_CONTEXT: ((context))
  
- put: prometheus-gateway
  params:
    metrics_file: metrics/metrics.prom
    job: zap-scanner
    instance: ((context))
```

### 5. Set Up Prometheus Pushgateway

For cloud.gov environments, you'll need to push metrics to a Prometheus Pushgateway:

```yaml
# Add to pipeline resources
- name: prometheus-gateway
  type: prometheus-pushgateway
  source:
    url: ((prometheus_pushgateway_url))
    job: zap-scanner
```

### 6. Configure Prometheus Scraping

Add scrape configuration to your Prometheus instance:

```yaml
scrape_configs:
  - job_name: 'pushgateway'
    honor_labels: true
    static_configs:
      - targets: ['pushgateway.service.cf.internal:9091']
```

## Dashboard Features

### Key Metrics Displayed
- **High/Medium/Low Risk Counts**: Real-time vulnerability counts
- **URLs Scanned**: Total coverage metrics
- **Scan Duration**: Performance monitoring
- **Vulnerability Trends**: Historical data visualization
- **Context Breakdown**: Per-context vulnerability distribution
- **Security Score**: Overall security posture percentage
- **Unique Vulnerabilities**: Distinct vulnerability types found

### Dashboard Panels

1. **Summary Stats Row** (Top)
   - High Risk Vulnerabilities (Red threshold at 1+)
   - Medium Risk Vulnerabilities (Yellow threshold at 5+)
   - Low Risk Vulnerabilities
   - Total URLs Scanned

2. **Trends Graph** (Middle Left)
   - Time series showing vulnerability trends
   - Color-coded by risk level
   - 24-hour default view

3. **Scan Duration Gauge** (Middle Right)
   - Shows last scan duration in minutes
   - Thresholds: Green (<60m), Yellow (60-90m), Red (>90m)

4. **Context Table** (Bottom)
   - Breakdown by scan context
   - Sortable by risk level
   - Color-coded cells

5. **Additional Metrics** (Bottom Row)
   - Unique Vulnerability Types
   - Security Score (percentage)
   - High Risk Status (Pass/Fail)
   - Last Scan Timestamp

## Alerting Configuration

### Create Alert Rules

1. Navigate to the dashboard
2. Click on a panel (e.g., High Risk Vulnerabilities)
3. Click "Edit" → "Alert" tab
4. Configure alert conditions:

```yaml
Alert Name: High Risk Vulnerabilities Detected
Condition: WHEN last() OF query(A) IS ABOVE 0
For: 5m
```

### Slack Notification Channel

1. Go to Alerting → Notification channels
2. Click "New channel"
3. Configure:
   - Name: `zap-slack-alerts`
   - Type: Slack
   - Webhook URL: Your Slack webhook
   - Channel: `#security-alerts`
   - Username: `ZAP Scanner`
   - Include image: Yes
   - Mention: `@security-team` (for critical)

### Alert Templates

Example alert message template:
```
🚨 *ZAP Security Alert*
*Status:* {{ .Status }}
*Alert:* {{ .RuleName }}
*Value:* {{ .Value }}
*Context:* {{ .Labels.context }}
*Dashboard:* {{ .DashboardURL }}

{{ if eq .Status "firing" }}
⚠️ Action Required: Review findings in DefectDojo
{{ else }}
✅ Alert resolved
{{ end }}
```

## Customization Options

### Adjust Time Ranges
- Default: 24 hours
- Modify in dashboard settings or use time picker

### Add Custom Variables
Template variables can be added for:
- Environment (dev/staging/prod)
- Team ownership
- Severity filters

### Custom Panels
Add panels for:
- Scan frequency metrics
- OWASP Top 10 mapping
- Compliance status
- Team-specific views

## Maintenance

### Regular Tasks
1. **Weekly**: Review dashboard accuracy
2. **Monthly**: Update thresholds based on baseline
3. **Quarterly**: Archive old metrics data

### Backup Dashboard
```bash
# Export dashboard JSON regularly
curl -H "Authorization: Bearer $GRAFANA_API_KEY" \
  https://grafana.fr.cloud.gov/api/dashboards/uid/zap-security-dashboard \
  > dashboard-backup-$(date +%Y%m%d).json
```

## Troubleshooting

### No Data Appearing
1. Verify Prometheus is receiving metrics:
   ```
   curl http://prometheus:9090/api/v1/query?query=zap_scan_total_urls
   ```
2. Check Pushgateway status
3. Verify pipeline is running export-metrics task

### Incorrect Values
1. Check metric labels match dashboard queries
2. Verify time ranges align
3. Review aggregation functions

### Performance Issues
1. Reduce query complexity
2. Adjust refresh interval (default: 30s)
3. Limit time range for historical queries

## Support

For issues or questions:
- cloud.gov support: support@cloud.gov
- Security team: cloud-gov-cybersecurity@gsa.gov
- Dashboard maintainer: See CODEOWNERS

## References
- [Grafana Documentation](https://grafana.com/docs/)
- [Prometheus Query Language](https://prometheus.io/docs/prometheus/latest/querying/basics/)
- [cloud.gov Monitoring Guide](https://cloud.gov/docs/monitoring/)

---
*Last Updated: August 2025*