---
name: Issue
about: Suggest a new issue for this project
title: "[short phrase distinguishing this from other Issues]"
labels: ''
assignees: ''

---
Short description explaining the high-level reason for the new issue.

## Notes

- Additional details, technical information, resource links, and implementation notes
- Excerpt and link to any relevant slack discussions

## Acceptance Criteria

- [ ] Determine next steps and acceptance criteria
