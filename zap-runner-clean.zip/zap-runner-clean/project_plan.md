---

## Project Overview & Vision

**Objective**: Create a robust, automated, and secure scanning platform using **OWASP ZAP** to continuously test internal and external cloud.gov infrastructure.

**Core Capabilities**:

* Schedule daily scans for multiple contexts (internal, external, unauthenticated, cloud‑gov‑pages, APIs).
* Support authentication methods: CF UAA, OpsUAA, or static bearer tokens.
* Centralize configuration: User-Agent, exclusion lists, reporting filters.
* Generate detailed reports (HTML, JSON, XML, SARIF) per hostname/context.
* Integrate with **DefectDojo** for vulnerability ingestion with deduplication.

**Key Value Drivers**:

* Full compliance to FedRamp/FISMA by maintaining continuous security scanning.
* Scalable foundations: easily add new contexts or APIs.
* Clear separation between auth, scanning logic, and pipeline orchestration.
* Defensive posture: limit attack surface, avoid overwhelming target systems.
* Lightweight infrastructure: ECR-hosted runner built from hardened base images.

---

## Phases & Milestones

### Phase 1: Stabilization & Centralization

* Finalize **central config** (UA, excludes, reporting criteria).
* Validate pipeline scheduling (daily 1 AM ET scans).
* Ensure all base contexts (internal, external, API, etc.) work end-to-end.
* Double-check that `addOns`, `options`, `replacer`, `report`, `exitStatus` are integrated in `zap-af.yml`.
* Ensure DefectDojo integration handles dedupe correctly (via XML imports).

### Phase 2: Enhanced API Handling & Usability

* Detect and import multiple OpenAPI specs per API context.
* Validate OpenAPI jobs (`apiFile`, `targetUrl`, `context`) are generated per spec. ([Cloud.gov][1], [GitHub][2], [U.S. Department of Defense CIO][3], [Medium][4], [ZAP][5])
* Add support for GraphQL or Postman imports if needed.
* Optionally, support HTTP Sender scripts for custom auth token handling. ([Medium][4])

### Phase 3: Developer Experience & Maintenance

* Add local dry-run mode (developer can test a plan locally using Docker).
* Add extensive documentation and contributor guides:

  * Add instructions for adding new contexts.
  * Define how to handle auth credentials via CredHub.
  * Provide onboarding steps for new teams.
* Implement CI checks:

  * Validate new contexts configs.
  * Lint config YAMLs.
  * Smoke tests of AF plan generation.

### Phase 4: Compliance & Advanced Security Checks

* Map NIST 800-53 controls covered by daily scanning (e.g. continuous monitoring, vulnerability alerts).
* Integrate additional security layers (e.g., accessibility or dependency scanning, as cloud.gov Pages support). ([Cloud.gov][6], [Cloud.gov][1], [ZAP][5], [GitHub][2], [Amazon Web Services, Inc.][7], [ZAP][8], [jit.io][9])
* Setup alert escalation workflows (e.g. Slack, PagerDuty) based on critical vulnerabilities.
* Collect metrics and logs on findings over time for historical reporting.

---

## Implementation Blueprint

```text
zap-runner/               # Root
└── ci/
    ├── common/
    │   ├── user-agent.txt
    │   ├── global-exclusions.txt
    │   └── reporting.yml
    ├── scan-contexts/
    │   ├── internal/
    │   ├── external/
    │   ├── api/
    │   └── ... (unauthenticated, test-template, etc.)
    ├── tasks/
    │   ├── acquire-auth.yml
    │   ├── zap-af.yml
    │   ├── push-defectdojo.yml
    │   └── process-results.yml
    ├── vars/zap-dast.yml
    ├── config.yml
    └── pipeline.yml
Dockerfile

README.md
SECURITY.md
Developer documentation

```

---

## Initial Quick Start Commands (for devs)

```bash
# Build runner locally
docker build --build-arg base_image=ubuntu:22.04 -t zap-runner:local .

# Test API context locally
docker run -v "$(pwd)/ci/scan-contexts/api:/zap/wrk" zap-runner:local \
  bash -c "zap.sh -cmd -autorun /zap/wrk/plan-api.yaml"

# List available contexts
ls ci/scan-contexts
```

---

## Quality Gates (To Automate)

* Validate **time resource** exists and triggers at intended window.
* Confirm all contexts generate at least one report file per template.
* Ensure no tokens are accidentally printed in any output or logs.
* CI should fail if new context producers no `config.yml` or missing `urls.txt`.
* Check that DefectDojo push uses XML and respects duplicate filtering.

---

## Tooling Suggestions

**Required**:

* ZAP & Automation Framework (already baked into runner)
* Docker
* Concourse

**Recommended**:

* `prettier` or YAML linter for config quality
* Lightweight monitoring (e.g., metrics from scan durations or counts)
* Slack integration (focused via `process-results.yml`)

**Optional**:

* Accessibility scanning plugin for Pages context
* Metrics dashboard (e.g., Grafana) tied to scan output trends
* Notification integration for critical findings

---

## Summary Roadmap

1. **Phase 1** (Immediate): Confirm reliability and consistency across contexts; full report and pipeline coverage.
2. **Phase 2**: Add robust API scanning with multiple OpenAPI specs.
3. **Phase 3**: Boost developer usability and automation guardrails.
4. **Phase 4**: Compliance & advanced scanning expansions (add accessibility, trends, metrics).

---

Let me know if you'd like a corresponding **jumpstart template** or initial CI config that enforces these quality gates.

[1]: https://cloud.gov/docs/overview/what-is-cloudgov/ "What is cloud.gov?"
[2]: https://github.com/orgs/cloud-gov/repositories "cloud-gov repositories"
[3]: https://dodcio.defense.gov/Portals/0/Documents/Library/DoDRefDesignCloudGithub.pdf "A DoD Enterprise DevSecOps Reference Design"
[4]: https://medium.com/%40jaishreepatidar/api-penetration-testing-using-zap-automation-framework-practical-implementation-bca6c28e0236 "API Penetration Testing: Using ZAP Automation Framework ..."
[5]: https://www.zaproxy.org/docs/desktop/addons/openapi-support/automation/ "OpenAPI Automation Framework Support - ZAP"
[6]: https://cloud.gov/pages/documentation/automated-site-reports/ "Automated Site Reports"
[7]: https://aws.amazon.com/govcloud-us/ "AWS GovCloud (US) - Amazon Web Services"
[8]: https://www.zaproxy.org/docs/automate/automation-framework/ "Automation Framework - ZAP"
[9]: https://www.jit.io/resources/owasp-zap/how-to-automate-owasp-zap "How to Automate OWASP ZAP"
